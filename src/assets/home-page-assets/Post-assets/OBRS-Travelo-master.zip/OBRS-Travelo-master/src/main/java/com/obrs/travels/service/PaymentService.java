package com.obrs.travels.service;

import com.obrs.travels.dto.PaymentDto;

public interface PaymentService {
	
	void paymentProcess(PaymentDto paymentDto);

}
