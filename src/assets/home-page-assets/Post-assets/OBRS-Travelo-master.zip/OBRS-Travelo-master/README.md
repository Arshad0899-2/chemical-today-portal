# OBRS-Travelo
Online Bus reservation system using Spring boot and MySQL
